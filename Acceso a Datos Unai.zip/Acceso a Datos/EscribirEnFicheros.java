import java.io.FileWriter;

public class EscribirEnFicheros {
public static void main(String[] args) {
	try{
		FileWriter Fichero= new FileWriter("Info-fichero.txt");
		Fichero.write("Nombre, Apellidos, Curso \n");
				
				
				Fichero.close();
	}  catch (Exception e){
		e.printStackTrace();
		}
	EscribeNombre("Unai, Ant�n, R�os","Info-fichero.txt");
}
static void EscribeNombre(String Nombre, String Ruta) {
	try{
		FileWriter Fichero= new FileWriter(Ruta,true);
		Fichero.write(Nombre+"\n");
				
				
				Fichero.close();
	}  catch (Exception e){
		e.printStackTrace();
		}
}
}
