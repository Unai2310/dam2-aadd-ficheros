package prueba;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.*;

public class Ejer3 {

	public static void main(String[] args) {
		
		Scanner scanner = null;
		FileInputStream fis = null;
        try {
        	fis = new FileInputStream("alumnos-dam2-nuevos.txt");
            System.setIn(fis);
            scanner = new Scanner(System.in);
            scanner.useDelimiter("\n");           
            nuevoList<String> nuevo = new nuevoList<String>();
            String line="";
            String[] datos = null;
            while (scanner.hasNext()){
            	nuevo.add(scanner.next());
            }
            try (PrintStream printStream1 = new PrintStream(new FileOutputStream("info-alumnos.txt"))) {
				System.setOut(printStream1);
				for(int i=1;i<nuevo.size();i++)
				{					
				datos=nuevo.get(i).split(",");
					
				if(datos.length>3)
					line =datos[1]+","+datos[2]+""+datos[3];
				else
					line =datos[1]+","+datos[2];
				
					System.out.println(line+", DAM2");
						
				}					
			} catch (IOException e) {
				e.printStackTrace();
			}         
        }
        catch (Exception e){
            if(scanner != null)
            	scanner.close();
            if(fis != null)
				try {
					fis.close();
				} catch (IOException e1) {
					e.printStackTrace();
				}
        }
	}
}