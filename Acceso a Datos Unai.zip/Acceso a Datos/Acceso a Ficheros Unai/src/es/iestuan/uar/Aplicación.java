package es.iestuan.uar;

import es.iestetuan.uar.fictexto.Programa;

public class Aplicaci�n {

	public static void main(String[] args) {
		Programa nuevo = new Programa();
		System.out.println(nuevo.getAlumno("619"));
		System.out.println(nuevo.getAlumnos());
	}
}
