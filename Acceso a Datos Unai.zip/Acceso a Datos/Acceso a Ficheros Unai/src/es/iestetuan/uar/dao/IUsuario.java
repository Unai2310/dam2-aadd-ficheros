package es.iestetuan.uar.dao;
import es.iestetuan.uar.vo.Alumno;
import java.util.List;

public interface IUsuario {
	public Alumno getAlumno(String id);
	public List<Alumno> getAlumnos();
}
