package es.iestetuan.uar.fictexto;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import es.iestetuan.uar.dao.IUsuario;
import es.iestetuan.uar.vo.Alumno;

public class Programa implements IUsuario {

	@Override
	public Alumno getAlumno(String id) {
		Alumno coincide = new Alumno();
		try(BufferedReader br=new BufferedReader(new FileReader("alumnos-dam2-nuevos.txt"))){
	        	String linea=br.readLine();
	        	linea=br.readLine();
	            while(linea!=null){	   
	            	String [] partes = linea.split(",");
	            	if (partes[0].equals(id)) {
	            		coincide.setNia(partes[0]);;
	            		coincide.setNombre(partes[1]);
	            		if (partes.length > 3) {
	            			coincide.setApellido1(partes[2]);
	            			coincide.setApellido2(partes[3]);
	            		} else {
	            			coincide.setApellido1(partes[2]);
	            			coincide.setApellido2("Sin 2� apellido");
	            		}
	            		return coincide;
	            	}
	            	linea=br.readLine();
	            } 
	        }catch(IOException e){
	            System.out.println("Error E/S: "+e);	        
	        }
		return coincide;
	}

	@Override
	public List<Alumno> getAlumnos() {
		ArrayList<Alumno> nuevo = new ArrayList<Alumno>();
		try(BufferedReader br=new BufferedReader(new FileReader("alumnos-dam2-nuevos.txt"))){
        	String linea=br.readLine();
        	linea=br.readLine();
            while(linea!=null){	   
            	Alumno chaval = new Alumno();
            	String [] partes = linea.split(",");
            	chaval.setNie(partes[0]);
            	chaval.setNombre(partes[1]);
            	chaval.setApellido1(partes[2]);
            	if (partes.length > 3) {
            		chaval.setApellido2(partes[3]);
            	}
            nuevo.add(chaval);
            linea=br.readLine();
            } 
        }catch(IOException e){
            System.out.println("Error E/S: "+e);	        
        }
		return nuevo;
	}

}
